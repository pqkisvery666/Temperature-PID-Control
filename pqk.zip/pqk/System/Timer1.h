#ifndef __TIMER4_H
#define __TIMER4_H

void Timer4_Init(void);

#endif
